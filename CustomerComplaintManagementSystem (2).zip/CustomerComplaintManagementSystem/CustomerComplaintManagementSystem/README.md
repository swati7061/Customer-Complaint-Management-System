# Customer Complaint Management System

A native Android Java project for Android Studio. It demonstrates registration/login, home dashboard, complaint creation, local complaint list/status updates, profile, and logout.

## Open and run
1. Extract the ZIP file.
2. In Android Studio choose **Open** and select the extracted `CustomerComplaintManagementSystem` folder (the folder containing `settings.gradle`).
3. Allow Gradle sync and SDK downloads to finish. Internet is needed for the first Gradle/plugin download.
4. Select an emulator or connect an Android phone with USB debugging enabled.
5. Click the green **Run** triangle.

## Requirements
- Android Studio with Android SDK Platform 35 (or allow Android Studio to install it)
- JDK 17 (Android Studio bundled JBR is recommended)
- Gradle plugin 8.7.3; wrapper distribution uses Gradle 8.10.2

## Important demo limitations
- Data is stored in a local SQLite database on the device.
- There is no cloud/server backend or real email/OTP authentication.
- For a classroom demo, account passwords are stored locally in plain text. Do not use real passwords or personal information; production use requires secure authentication and password hashing.
- Complaint status can be changed manually in the demo; there is no admin dashboard or live tracking service.
